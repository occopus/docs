create database IF NOT EXISTS dataavenue;
create user IF NOT EXISTS 'da'@'%' IDENTIFIED BY 'da';
grant all privileges on dataavenue.* TO 'da'@'%';
flush privileges;
