#!/bin/bash
# Usage: test.sh [dataavenue host] [dataavenue key]
#set -x

# load credentials, set constants
. ./test.config
DATA_AVENUE_HOST=localhost
if [ "$#" -gt 0 ]; then DATA_AVENUE_HOST=$1 ; else echo Using default dataavenue host: localhost ; fi
KEY=1a7e159a-ffd8-49c8-8b40-549870c70e73
if [ "$#" -gt 1 ]; then KEY=$2 ; else echo Using default dataavenue key: $KEY ; fi
CURL_OPTIONS='-k -f -sS -o /dev/null'
function check() { if [ $? -eq 0 ]; then echo '  'PASSED: $1 ; else echo '  'FAILED: $1 ; fi }

# test version
echo Testing Data Avenue version...
curl $CURL_OPTIONS https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/version ; check "version"

# test SFTP
if [ -n "${SFTP_HOST}" ] && [ -n "${SFTP_USERNAME}" ] && [ -n "${SFTP_PASSWORD}" ]; then
  echo Testing SFTP...
  SFTP_HEADERS=$CURL_OPTIONS' -H "X-Key: ${KEY}" -H "X-Username: ${SFTP_USERNAME}" -H "X-Password: ${SFTP_PASSWORD}"'
  eval curl $SFTP_HEADERS -X GET    '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/"'            https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/directory ; check "sftp list"
  eval curl $SFTP_HEADERS -X POST   '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/newdir/"'     https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/directory ; check "sftp mkdir"
  eval curl $SFTP_HEADERS -X GET    '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/newdir/"'     https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/attributes ; check "sftp dir attributes"
  eval curl $SFTP_HEADERS -X POST   '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/newdir/test" -H "Content-Type: application/octet-stream" --data-binary @test.sh' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/file ; check "sftp upload"
  eval curl $SFTP_HEADERS -X GET    '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/newdir/test"' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/attributes ; check "sftp file attributes"
  eval curl $SFTP_HEADERS -X GET    '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/newdir/test"' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/file ; check "sftp download"
  eval curl $SFTP_HEADERS -X DELETE '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/newdir/test"' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/file ; check "sftp delete"
  eval curl $SFTP_HEADERS -X DELETE '-H "X-URI: sftp://$SFTP_HOST$SFTP_DIR/newdir/"'     https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/directory ; check "sftp rmdir"
else 
  echo Skipping SFTP tests \(not configured\)
fi

# test S3
if [ -n "${S3_HOST}" ] && [ -n "${ACCESS_KEY}" ] && [ -n "${SECRET_KEY}" ]; then
  echo Testing S3...
  S3_HEADERS=$CURL_OPTIONS' -H "X-Key: ${KEY}" -H "X-Username: ${ACCESS_KEY}" -H "X-Password: ${SECRET_KEY}"'
  eval curl $S3_HEADERS -X GET    '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/"'            https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/directory ; check "s3 list"
  eval curl $S3_HEADERS -X POST   '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/newdir/"'     https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/directory ; check "s3 mkdir"
  eval curl $S3_HEADERS -X GET    '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/newdir/"'     https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/attributes ; check "s3 dir attributes"
  eval curl $S3_HEADERS -X POST   '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/newdir/test" -H "Content-Type: application/octet-stream" --data-binary @test.sh' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/file ; check "s3 upload"
  eval curl $S3_HEADERS -X GET    '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/newdir/test"' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/attributes ; check "s3 file attributes"
  eval curl $S3_HEADERS -X GET    '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/newdir/test"' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/file ; check "s3 download"
  eval curl $S3_HEADERS -X DELETE '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/newdir/test"' https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/file ; check "s3 delete"
  eval curl $S3_HEADERS -X DELETE '-H "X-URI: s3://$S3_HOST/$S3_BUCKET/newdir/"'     https://${DATA_AVENUE_HOST}:8443/dataavenue/rest/directory ; check "s3 rmdir"
else 
  echo Skipping S3 tests \(not configured\)
fi

echo Done
